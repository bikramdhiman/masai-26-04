
export const database = "https://your-project.firebaseio.com"; // replace with your actual firebase db url
